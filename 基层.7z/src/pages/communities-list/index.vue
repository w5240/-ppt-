<template>
<div class="communities-list">
  <layout></layout>
</div>
</template>
<script>
import layout from '@/components/layouts/with-touch-header';
export default {
  components: {
    layout
  }
};
</script>

<style lang="scss" scoped>

</style>
